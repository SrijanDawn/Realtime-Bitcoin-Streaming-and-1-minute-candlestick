# Realtime-Bitcoin-Streaming-and-1-minute-candlestick
In this tutorial, I will show you how to stream realtime Bitcoin data in USD with Websocket and Python programming. With the realtime prices, we are going to animate a 1 minute candlestick chart.

Youtube video:
https://www.youtube.com/watch?v=o_RFdbAQJ3w
